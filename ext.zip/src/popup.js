(function () {
    function applyStatus(elementId, status) {
        const element = document.getElementById(elementId);
        if (!element) {
            return;
        }

        element.textContent = status.label;
        element.setAttribute('data-state', status.state);
    }

    function formatReason(text) {
        if (!text) {
            return 'Error';
        }

        const cleaned = text.replace(/[-_]/g, ' ').trim();
        if (!cleaned) {
            return 'Error';
        }

        return cleaned.charAt(0).toUpperCase() + cleaned.slice(1);
    }

    function interpretStatus(result) {
        if (!result || result.ok === false) {
            return {
                label: formatReason(result && result.reason),
                state: 'error'
            };
        }

        if (result.tabCount > 0) {
            return {
                label: result.tabCount === 1 ? 'Ready' : result.tabCount + ' tabs',
                state: 'ready'
            };
        }

        return {
            label: 'Not detected',
            state: 'missing'
        };
    }

    function init() {
        const loading = { label: 'Checking...', state: 'checking' };
        applyStatus('launchblitzStatus', loading);
        applyStatus('axiomStatus', loading);

        chrome.runtime.sendMessage({ type: 'check-status' }, (response) => {
            const runtimeError = chrome.runtime && chrome.runtime.lastError;
            if (runtimeError) {
                const fallback = { label: formatReason(runtimeError.message), state: 'error' };
                applyStatus('launchblitzStatus', fallback);
                applyStatus('axiomStatus', fallback);
                return;
            }

            if (!response) {
                const fallback = { label: 'No response', state: 'error' };
                applyStatus('launchblitzStatus', fallback);
                applyStatus('axiomStatus', fallback);
                return;
            }

            applyStatus('launchblitzStatus', interpretStatus(response.launchblitz));
            applyStatus('axiomStatus', interpretStatus(response.axiom));
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
