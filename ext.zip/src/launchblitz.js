// Launchblitz content script relaying Vamp payloads into the page as vampCoin events.
(function initLaunchblitzRelay() {
    console.log('[Blitz Extension] Launchblitz relay content script initialized.');

    function dispatchVampCoinEvent(coin) {
        if (!coin) {
            return;
        }

        console.log('[Blitz Extension] Dispatching vampCoin event with payload:', coin);
        const vampEvent = new CustomEvent('vampCoin', { detail: coin });
        window.dispatchEvent(vampEvent);
    }

    chrome.runtime.onMessage.addListener((message) => {
        if (!message || message.type !== 'vamp-coin') {
            return;
        }

        console.log('[Blitz Extension] Launchblitz content script received vamp-coin message:', message.payload);
        dispatchVampCoinEvent(message.payload);
    });
})();
