// Background service worker responsible for relaying Vamp payloads to launchblitz.ai tabs.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || !message.type) {
        return;
    }

    if (message.type === 'check-status') {
        chrome.tabs.query({
            url: [
                'https://launchblitz.ai/*',
                'https://www.launchblitz.ai/*'
            ]
        }, (launchblitzTabs) => {
            const launchError = chrome.runtime.lastError;
            if (launchError) {
                sendResponse({
                    launchblitz: { ok: false, reason: launchError.message },
                    axiom: { ok: false, reason: 'launchblitz query failed' }
                });
                return;
            }

            const launchTabCount = launchblitzTabs ? launchblitzTabs.length : 0;

            chrome.tabs.query({
                url: [
                    'https://axiom.trade/*',
                    'https://*.axiom.trade/*'
                ]
            }, (axiomTabs) => {
                const axiomError = chrome.runtime.lastError;
                if (axiomError) {
                    sendResponse({
                        launchblitz: { ok: true, tabCount: launchTabCount },
                        axiom: { ok: false, reason: axiomError.message }
                    });
                    return;
                }

                sendResponse({
                    launchblitz: { ok: true, tabCount: launchTabCount },
                    axiom: { ok: true, tabCount: axiomTabs ? axiomTabs.length : 0 }
                });
            });
        });

        return true;
    }

    if (message.type !== 'vamp-coin' || !message.payload) {
        return;
    }

    const coin = message.payload;
    const senderTabId = sender && sender.tab ? sender.tab.id : 'unknown';
    console.log('[Blitz Extension] Background received vamp-coin payload from tab:', senderTabId, coin);

    chrome.tabs.query({
        url: [
            'https://launchblitz.ai/*',
            'https://www.launchblitz.ai/*'
        ]
    }, (tabs) => {
        if (chrome.runtime.lastError) {
            console.warn('[Blitz Extension] Failed to query launchblitz.ai tabs:', chrome.runtime.lastError.message);
            sendResponse({ forwarded: false, reason: 'query-failed' });
            return;
        }

        if (!tabs || tabs.length === 0) {
            console.warn('[Blitz Extension] No launchblitz.ai tab detected to receive Vamp payload.');
            sendResponse({ forwarded: false, reason: 'no-tab' });
            return;
        }

        console.log('[Blitz Extension] Forwarding Vamp payload to launchblitz.ai tabs:', tabs.map((tab) => tab.id));
        tabs.forEach((tab) => {
            if (!tab.id) {
                return;
            }

            chrome.tabs.sendMessage(tab.id, {
                type: 'vamp-coin',
                payload: coin
            }, () => {
                const forwardError = chrome.runtime && chrome.runtime.lastError;
                if (forwardError) {
                    console.warn('[Blitz Extension] Failed to deliver Vamp payload to tab', tab.id, forwardError.message);
                } else {
                    console.log('[Blitz Extension] Delivered Vamp payload to launchblitz.ai tab', tab.id);
                }
            });
        });

        sendResponse({ forwarded: true, tabCount: tabs.length });
    });

    return true;
});
